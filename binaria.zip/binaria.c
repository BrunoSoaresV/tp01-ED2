//Criação de uma árvore binária não balanceada

#include "binaria.h"
#define TAM_NOME 60 //tamanho do nome dos arquivos, se necessário. Até o momento não foi necessário, pois é passado já como ponteiro


//Cria um novo nó na árvore
tNo criaNovoNo(Registro dados){
    tNo novoNo;
    novoNo.dados = dados;
    novoNo.esq = -1;
    novoNo.dir = -1;
    return novoNo;
}

/*//Aqui é gerado o arquivo no qual ficará armazenada a árvore binária
FILE* criaArquivo(FILE* arq, int quantidade){
    FILE *arvore;

    if((arvore = fopen("treefile.bin", "wb")) == NULL){
        printf("Não conseguiu criar o arquivo para armazenar a árvore\n");
        return NULL;
    }

    return arvore;
}*/

//Os elementos do arquivo são percorridos e inseridos no novo arquivo
// Inserir enquanto tiver registros e páginas
// a última página tem o total de registros menos o quanto já foram inseridos (qtd de páginas * qtd por página)
bool geraArquivo(FILE* origem, int quantidade){
    Registro dados[ITENSPAGINA];
    FILE* arvore;

    //São definidas algumas variáveis de controle de fluxo
    int qtdItens = 0, paginaAtual = 0; //quantidade de itens já inseridos. // Valor da página atual
    int qtdItensPag = ITENSPAGINA; //quantidade de itens na página atual. Pode ser diferente para a última página
    int totalPaginas = quantidade/ITENSPAGINA; //total previsto de páginas. Usado para controlar quando o processo deve ser encerrado

    if((arvore = fopen("treefile.bin", "wb")) == NULL){
        printf("Não conseguiu criar o arquivo para armazenar a árvore\n");
        return false;
    }

    while(paginaAtual <= totalPaginas){
        if(paginaAtual == totalPaginas) qtdItensPag = quantidade - (paginaAtual*ITENSPAGINA);

        if(fread(&dados, sizeof(Registro), qtdItensPag, origem) == NULL){
            printf("Erro fatal ao tentar ler arquivo de origem");
            return false;
        };

        for(int i = 0; i < qtdItensPag; i++) {
            insere(dados[i], qtdItens, arvore);
            qtdItens++;
            //Colocar um return booleano na insere, ou fazer a verificação de erro nela mesma?
        }
        paginaAtual++;
    }
    fclose(arvore);
    return true; //Arquivo árvore gerado com sucesso
}

bool insere(Registro dado, int qtdItens, FILE* arvore){
    
    // o dado recebido é atribuído a um nó
    tNo novoNo, noAtual;
    novoNo = criaNovoNo(dado);

    // caso a árvore ainda não tenha itens, este será o primeiro item dela
    if(qtdItens == 0){
        if(fwrite(&novoNo, sizeof(tNo), 1, arvore) == NULL) return false;
        return true;
    }

    
    // procura o local correto de inserção (à direita ou à esquerda)
    // o nó atual deve ser lido o tempo todo para motivos de comparação. O processo deve ocorrer até que ocorra erro ou que seja bem sucedido.
    // por isso, a melhor opção é um while

    bool dadoInserido = false;

    while(dadoInserido == false){

        // le o nó atual

        if(fread(&noAtual, sizeof(tNo), 1, arvore) == NULL){
            printf("Erro na leitura do arquivo árvore");
            return false;
        }

        // compara se o novo é maior. 
        if(novoNo.dados.chave > noAtual.dados.chave){
            //Se sim, verifica se o atual tem um filho à direita. Se não tiver, insere
            if(noAtual.dir == -1){
                noAtual.dir = qtdItens;
            }
            //Se tiver, se move para ele
        }

        

        // se o novo for menor, verifica se o atual tem um filho à esquerda
        // se não tiver, insere. Se tiver, se move para ele

        // se não for maior nem menor, são iguais, e não ocorre inserção



    }
    //Rest of the code yet to do
}

// Função de inserir
// Se tiver zero registros, é o nó raiz