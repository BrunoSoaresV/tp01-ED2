#ifndef BINARIA_H
#define BINARIA_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "struct.h"

typedef struct{
    Registro dados;
    int esq, dir;
}tNo;

tNo criaNovoNo(Registro dados);

#endif